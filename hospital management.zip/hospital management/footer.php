<footer
    style="text-align: center; background-color:RGB(33, 37, 41); color: #ffffff; padding: 1rem 0; position: absolute; bottom: 0; width: 100%;">
    &copy; 2025 BookDoc | All rights reserved | Designed for efficient healthcare solutions
</footer>